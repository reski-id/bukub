# project-book-nativescript-1
Arsip projek buku "Membuat aplikasi mobile “native” dengan javascript By NativeScript"
