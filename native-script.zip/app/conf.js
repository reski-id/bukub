module.exports = {
    domain: "http://192.168.1.119/my_contact/index.php",
    timeloader:100,
    transduration: 200,
    curve:"linear"
};
